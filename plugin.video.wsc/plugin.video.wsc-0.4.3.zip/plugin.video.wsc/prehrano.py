# -*- coding: utf-8 -*-
# Vlastni uprava (2026-11): historie prehravani ulozena v datech doplnku (jen na tomto zarizeni).

import io
import json
import os
import time
import xbmc
import xbmcgui
import xbmcplugin

import filmy
import filmy_core as core

FILE = 'play_history.json'
LIMIT = 100


def _path():
    return os.path.join(filmy._ws()._profile, FILE)


def load():
    try:
        with io.open(_path(), 'r', encoding='utf8') as f:
            data = json.loads(f.read())
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save(rows):
    ws = filmy._ws()
    try:
        if not os.path.exists(ws._profile):
            os.makedirs(ws._profile)
        with io.open(_path(), 'w', encoding='utf8') as f:
            f.write(json.dumps(rows[:LIMIT], ensure_ascii=False))
    except Exception:
        pass


def remember(ident, name, size=None, meta=None):
    """Zapise prehrany soubor na zacatek historie (bez duplicit)."""
    if not ident:
        return
    old = [r for r in load() if r.get('ident') == ident]
    rows = [r for r in load() if r.get('ident') != ident]
    row = {'ident': ident, 'name': name or ident, 'size': size or '', 'time': int(time.time())}
    if old:  # pozici z minula nechat
        for k in ('pos', 'total', 'done'):
            if k in old[0]:
                row[k] = old[0][k]
        if not row['size']:
            row['size'] = old[0].get('size', '')
        if not meta:
            meta = old[0].get('meta')
    if meta:
        row['meta'] = meta
    rows.insert(0, row)
    save(rows)


def position(ident):
    """Ulozena pozice v sekundach (0 = od zacatku)."""
    for r in load():
        if r.get('ident') == ident:
            try:
                return float(r.get('pos') or 0)
            except ValueError:
                return 0
    return 0


def store_position(ident, pos, total):
    rows = load()
    for r in rows:
        if r.get('ident') == ident:
            done = total > 0 and pos > total * 0.93
            r['pos'] = 0 if (done or pos < 60) else int(pos)
            r['total'] = int(total)
            r['done'] = bool(done)
            save(rows)
            return


def clock(seconds):
    seconds = int(seconds)
    return '%d:%02d:%02d' % (seconds // 3600, (seconds % 3600) // 60, seconds % 60)


def ask_resume(ident):
    """Zepta se, jestli pokracovat. Vrati pozici v sekundach nebo 0."""
    pos = position(ident)
    if pos < 60:
        return 0
    if xbmcgui.Dialog().yesno(u'Pokra\u010dovat?', u'Naposledy jsi skon\u010dil v \u010dase ' + clock(pos) + '.',
                              nolabel=u'Od za\u010d\u00e1tku', yeslabel=u'Pokra\u010dovat'):
        return pos
    return 0


def watch(ident, resume):
    """Bezi po spusteni prehravani: pripadne preskoci na ulozenou pozici a prubezne ji uklada."""
    player = xbmc.Player()
    monitor = xbmc.Monitor()
    start = time.time()
    while not player.isPlayingVideo() and time.time() - start < 90:
        if monitor.waitForAbort(0.5):
            return
    if not player.isPlayingVideo():
        return
    try:
        playing = player.getPlayingFile()
    except Exception:
        return
    seeked = not resume
    pos = total = 0
    saved = time.time()
    while player.isPlayingVideo():
        try:
            if player.getPlayingFile() != playing:
                break
            now = player.getTime()
            total = player.getTotalTime()
        except Exception:
            break
        if not seeked:
            seeked = True
            if now < resume - 15:
                try:
                    player.seekTime(resume)
                except Exception:
                    pass
                now = resume
        pos = now
        if time.time() - saved > 15:
            store_position(ident, pos, total)
            saved = time.time()
        if monitor.waitForAbort(2):
            break
    store_position(ident, pos, total)


def menu(params):
    ws = filmy._ws()
    xbmcplugin.setPluginCategory(ws._handle, u'Historie přehrávání')
    if 'remove' in params:
        save([r for r in load() if r.get('ident') != params['remove']])
    if 'clear' in params:
        save([])
    rows = load()
    for r in rows:
        when = time.strftime('%d.%m. %H:%M', time.localtime(r.get('time', 0)))
        item = {'ident': r['ident'], 'name': r['name'], 'size': r.get('size') or ''}
        state = ''
        if r.get('done'):
            state = u'dokoukáno, '
        elif r.get('pos') and r.get('total'):
            state = u'%d %%, ' % round(100.0 * r['pos'] / r['total'])
        text = core.label(item) + u'  (' + state + when + u')'
        li = xbmcgui.ListItem(label=text)
        li.setInfo('video', {'title': text})
        li.setProperty('IsPlayable', 'true')
        li.addContextMenuItems([(u'Odebrat z historie', 'Container.Update(' + ws.get_url(action='played', remove=r['ident']) + ')')])
        xbmcplugin.addDirectoryItem(ws._handle, ws.get_url(action='play', ident=r['ident'], name=r['name'], size=r.get('size') or '',
                                                           **(r.get('meta') or {})), li, False)
    if rows:
        filmy._folder(u'Smazat celou historii', 'DefaultAddonNone.png', action='played', clear=1)
    xbmcplugin.endOfDirectory(ws._handle, updateListing=('remove' in params or 'clear' in params))
