# -*- coding: utf-8 -*-
# Vlastni uprava (2026-11): razeni vysledku z Webshare a klient TMDB.
# Zadny import z Kodi - jde testovat na pocitaci.

import difflib
import re
import unicodedata

VIDEO_EXT = ('mkv', 'mp4', 'avi', 'm4v', 'ts', 'mov', 'mpg', 'mpeg', 'wmv', 'webm', 'm2ts')
MIN_FILM_SIZE = 300 * 1024 * 1024
MIN_EPISODE_SIZE = 50 * 1024 * 1024

CZ_TOKENS = ('cz', 'cze', 'czech', 'cesky', 'ceska', 'ceske', 'cestina')
SK_TOKENS = ('sk', 'svk', 'slovak', 'slovensky')
SUB_TOKENS = ('tit', 'titulky', 'sub', 'subs', 'subtitles', 'cztit', 'titcz')
JUNK_TOKENS = ('sample', 'trailer', 'ukazka', 'teaser', 'scenes', 'scene')
CAM_TOKENS = ('cam', 'hdcam', 'camrip', 'telesync', 'hdts', 'tsrip', 'kinorip')


def norm(text):
    """Bez diakritiky, mala pismena, oddelovace jako mezery."""
    text = unicodedata.normalize('NFKD', text or '')
    text = ''.join(c for c in text if not unicodedata.combining(c)).lower()
    return re.sub(r'[^a-z0-9]+', ' ', text).strip()


LEET = {'3': 'e', '1': 'i', '0': 'o', '4': 'a', '5': 's', '7': 't', '@': 'a', '$': 's'}


def unleet(token):
    """'f1ght3r' -> 'fighter'. Ciste cisla (rok, 1080) nechava byt."""
    if token.isdigit() or not any(c.isdigit() for c in token):
        return token
    return ''.join(LEET.get(c, c) for c in token)


def title_match(title, tokens):
    """Je nazev filmu v nazvu souboru? Snese preklep a cislice misto pismen."""
    words = norm(title).split()
    if not words:
        return False
    pool = set(tokens) | set(unleet(t) for t in tokens)
    hit = 0
    for w in words:
        if w in pool:
            hit += 1
        elif len(w) >= 4 and difflib.get_close_matches(w, pool, n=1, cutoff=0.8):
            hit += 1
    need = len(words) if len(words) <= 2 else int(round(len(words) * 0.75))
    return hit >= need


def episode_match(normalized_name, season, episode):
    """Je v nazvu souboru tato epizoda? Zna tvary S01E02, s1e2, S01 E02, 1x02."""
    s, e = int(season), int(episode)
    pats = (r'(?<![a-z0-9])s0*%d ?e0*%d(?![0-9])' % (s, e), r'(?<![a-z0-9])0*%dx0*%d(?![0-9])' % (s, e))
    return any(re.search(p, normalized_name) for p in pats)


def ext_of(name):
    return name.rsplit('.', 1)[-1].lower() if '.' in name else ''


def language(tokens):
    """Vrati (stitek, body)."""
    dub = any(t.startswith('czdab') or t.startswith('dabing') or t == 'dab' for t in tokens)
    cz = dub or any(t in CZ_TOKENS for t in tokens)
    sub = any(t in SUB_TOKENS for t in tokens)
    if cz and (dub or not sub):
        return 'CZ', 40
    if cz and sub:
        return 'CZ tit', 15
    if any(t in SK_TOKENS for t in tokens):
        return 'SK', 12
    return '', 0


def quality(tokens):
    """Vrati (stitek, body)."""
    joined = ' '.join(tokens)
    if any(t in ('2160p', '2160', '4k', 'uhd') for t in tokens):
        return '4K', 28
    if '1080' in joined or 'fullhd' in joined or 'full hd' in joined:
        return '1080p', 30
    if '720' in joined:
        return '720p', 20
    if any(t in ('dvdrip', '480p', '576p', 'xvid', 'divx', 'tvrip') for t in tokens):
        return 'SD', 5
    return '', 10


def describe(item, titles=None, year=None, episode=None, min_size=MIN_FILM_SIZE):
    """Ohodnoti jeden soubor z Webshare. Vrati slovnik se skore a stitky."""
    name = item.get('name') or ''
    n = norm(name)
    tokens = n.split()
    try:
        size = int(item.get('size') or 0)
    except ValueError:
        size = 0
    lang, lang_pts = language(tokens)
    qual, qual_pts = quality(tokens)
    score = lang_pts + qual_pts
    junk = any(t in JUNK_TOKENS for t in tokens)
    if junk:
        score -= 80
    if any(t in CAM_TOKENS for t in tokens):
        score -= 40
    if size < min_size:
        score -= 50
    score += min(size / float(1024 ** 3), 15.0)
    try:
        votes = int(item.get('positive_votes') or 0) - int(item.get('negative_votes') or 0)
    except ValueError:
        votes = 0
    score += max(-10, min(10, votes * 2))
    title_ok = True
    if titles:
        title_ok = any(title_match(t, tokens) for t in titles)
        if title_ok:
            score += 20
    # rok v nazvu souboru: jiny rok nez u filmu = jiny (stary) film stejneho jmena
    wrong_year = False
    if year and str(year).isdigit():
        y = int(year)
        title_tokens = set()
        for t in (titles or []):
            title_tokens |= set(norm(t).split())
        years = [int(t) for t in tokens if re.match(r'^(19|20)[0-9]{2}$', t) and t not in title_tokens]
        if years:
            if any(abs(v - y) <= 1 for v in years):
                score += 15
            else:
                wrong_year = True
                score -= 60
        else:
            score -= 10
    episode_ok = True
    if episode:
        episode_ok = episode_match(n, episode[0], episode[1])
    return {'score': score, 'wrong_year': wrong_year, 'episode_ok': episode_ok, 'lang': lang, 'quality': qual, 'size': size, 'junk': junk,
            'title_ok': title_ok, 'video': ext_of(name) in VIDEO_EXT}


def tag(desc):
    parts = []
    if desc['lang']:
        parts.append('[' + desc['lang'] + ']')
    if desc['quality']:
        parts.append(desc['quality'])
    return ' '.join(parts)


def version_newer(a, b):
    """Je verze a novejsi nez b? ('0.4.10' > '0.4.9')"""
    def parts(v):
        return [int(x) for x in re.findall(r'[0-9]+', v or '')]
    return parts(a) > parts(b)


def size_text(size):
    """Velikost v bajtech -> '4.2 GB' / '700 MB'."""
    try:
        size = float(size)
    except (TypeError, ValueError):
        return '?'
    if size <= 0:
        return '?'
    if size >= 1024 ** 3:
        return '%.1f GB' % (size / 1024 ** 3)
    return '%d MB' % round(size / 1024 ** 2)


def label(item, desc=None):
    """Jednotny radek souboru: [jazyk] rozliseni · velikost · nazev."""
    if desc is None:
        desc = describe(item)
    size = size_text(item.get('size')) if item.get('size') else (item.get('sizelized') or '?')
    return u'[%s] %s \u00b7 %s \u00b7 %s' % (desc['lang'] or '?', desc['quality'] or '?', size, item.get('name') or '')


def rank(items, titles=None, year=None, strict=False, episode=None):
    """Seradi soubory od nejlepsiho. strict=True vyhodi ukazky, male soubory a jine filmy."""
    min_size = MIN_EPISODE_SIZE if episode else MIN_FILM_SIZE
    seen = set()
    rows = []
    for item in items:
        ident = item.get('ident')
        if ident in seen:
            continue
        seen.add(ident)
        rows.append((describe(item, titles, year, episode, min_size), item))
    if strict:
        kept = [r for r in rows if r[0]['video'] and not r[0]['junk']
                and r[0]['size'] >= min_size and r[0]['title_ok'] and not r[0]['wrong_year']
                and r[0]['episode_ok']]
        rows = kept
    rows.sort(key=lambda r: -r[0]['score'])
    return rows


class Tmdb(object):
    BASE = 'https://api.themoviedb.org/3'
    IMG = 'https://image.tmdb.org/t/p/'
    LISTS = {'popular': '/movie/popular', 'now_playing': '/movie/now_playing',
             'top_rated': '/movie/top_rated', 'upcoming': '/movie/upcoming'}

    def __init__(self, key, requests_module, lang='cs-CZ', region='CZ'):
        self.key = (key or '').strip()
        self.requests = requests_module
        self.lang = lang
        self.region = region

    def get(self, path, **params):
        params.setdefault('language', self.lang)
        headers = {}
        if len(self.key) > 40:  # dlouhy "Read Access Token" (v4)
            headers['Authorization'] = 'Bearer ' + self.key
        else:  # kratky "API Key" (v3)
            params['api_key'] = self.key
        r = self.requests.get(self.BASE + path, params=params, headers=headers, timeout=15)
        r.raise_for_status()
        return r.json()

    def movies(self, kind, page=1, genre=None, query=None):
        if kind == 'search':
            data = self.get('/search/movie', query=query, page=page, include_adult='false')
        elif kind == 'genre':
            data = self.get('/discover/movie', with_genres=genre, page=page, region=self.region,
                            sort_by='popularity.desc', include_adult='false', **{'vote_count.gte': 200})
        else:
            data = self.get(self.LISTS[kind], page=page, region=self.region)
        return [self.movie(m) for m in data.get('results', [])], int(data.get('total_pages', 1))

    def genres(self):
        return self.get('/genre/movie/list').get('genres', [])

    def movie(self, m):
        date = m.get('release_date') or ''
        return {
            'title': m.get('title') or m.get('original_title') or '?',
            'orig': m.get('original_title') or '',
            'year': date[:4],
            'plot': m.get('overview') or '',
            'rating': float(m.get('vote_average') or 0),
            'poster': (self.IMG + 'w500' + m['poster_path']) if m.get('poster_path') else '',
            'fanart': (self.IMG + 'w1280' + m['backdrop_path']) if m.get('backdrop_path') else '',
        }

    # --- serialy ---
    TV_LISTS = {'top_rated': '/tv/top_rated', 'on_the_air': '/tv/on_the_air'}

    def shows(self, kind, page=1, genre=None, query=None):
        if kind == 'search':
            data = self.get('/search/tv', query=query, page=page, include_adult='false')
        elif kind in ('genre', 'popular'):
            extra = {'vote_count.gte': 300 if kind == 'popular' else 100}
            if genre:
                extra['with_genres'] = genre
            data = self.get('/discover/tv', page=page, sort_by='popularity.desc', include_adult='false', **extra)
        else:
            data = self.get(self.TV_LISTS[kind], page=page)
        return [self.show(m) for m in data.get('results', [])], int(data.get('total_pages', 1))

    def tv_genres(self):
        return self.get('/genre/tv/list').get('genres', [])

    def show(self, m):
        date = m.get('first_air_date') or ''
        return {
            'id': m.get('id'),
            'title': m.get('name') or m.get('original_name') or '?',
            'orig': m.get('original_name') or '',
            'year': date[:4],
            'plot': m.get('overview') or '',
            'rating': float(m.get('vote_average') or 0),
            'poster': (self.IMG + 'w500' + m['poster_path']) if m.get('poster_path') else '',
            'fanart': (self.IMG + 'w1280' + m['backdrop_path']) if m.get('backdrop_path') else '',
        }

    def seasons(self, tv_id):
        d = self.get('/tv/%s' % tv_id)
        out = []
        for x in d.get('seasons', []):
            if not x.get('episode_count'):
                continue
            out.append({'number': x.get('season_number'), 'name': x.get('name') or '', 'count': x.get('episode_count'),
                        'plot': x.get('overview') or '',
                        'poster': (self.IMG + 'w500' + x['poster_path']) if x.get('poster_path') else ''})
        return self.show(d), out

    def episodes(self, tv_id, season):
        d = self.get('/tv/%s/season/%s' % (tv_id, season))
        return [{'number': e.get('episode_number'), 'name': e.get('name') or '', 'plot': e.get('overview') or '',
                 'date': e.get('air_date') or '',
                 'still': (self.IMG + 'w500' + e['still_path']) if e.get('still_path') else ''}
                for e in d.get('episodes', [])]
