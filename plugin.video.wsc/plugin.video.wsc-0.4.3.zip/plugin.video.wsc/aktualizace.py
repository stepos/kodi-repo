# -*- coding: utf-8 -*-
# Vlastni uprava (2026-11): rucni kontrola aktualizaci z nastaveni doplnku.

import requests
import xbmc
import xbmcgui
from xml.etree import ElementTree as ET

import filmy
import filmy_core as core

REPO_XML = 'https://raw.githubusercontent.com/stepos/kodi-repo/main/addons.xml'
ADDON_ID = 'plugin.video.wsc'
REPO_ID = 'repository.stepos'


def latest():
    """Nejnovejsi vydana verze doplnku podle verejneho repozitare."""
    r = requests.get(REPO_XML, timeout=10, headers={'Cache-Control': 'no-cache'})
    r.raise_for_status()
    for a in ET.fromstring(r.content):
        if a.get('id') == ADDON_ID:
            return a.get('version')
    return None


def check(params):
    ws = filmy._ws()
    now = ws._addon.getAddonInfo('version')
    title = u'Aktualizace Webshare Cinema'
    try:
        new = latest()
    except Exception as e:
        xbmc.log('WSC aktualizace chyba: ' + str(e), xbmc.LOGWARNING)
        new = None
    if not new:
        xbmcgui.Dialog().ok(title, u'Nepodařilo se zjistit nejnovější verzi (máš %s). Zkus to později.' % now)
        return
    if not core.version_newer(new, now):
        xbmcgui.Dialog().ok(title, u'Máš nejnovější verzi %s.' % now)
        return
    if xbmc.getCondVisibility('System.HasAddon(%s)' % REPO_ID):
        xbmc.executebuiltin('UpdateAddonRepos')
        xbmcgui.Dialog().ok(title, u'Je k dispozici verze %s (máš %s). Spustil jsem kontrolu aktualizací, Kodi ji během chvíle nainstaluje. '
                                   u'Kdyby ne: Doplňky → Dostupné aktualizace.' % (new, now))
    else:
        xbmcgui.Dialog().ok(title, u'Je k dispozici verze %s (máš %s), ale chybí repozitář „Stepos – doplňky“. '
                                   u'Nainstaluj ho ze souboru repository.stepos-1.0.0.zip, pak se doplněk aktualizuje sám.' % (new, now))
