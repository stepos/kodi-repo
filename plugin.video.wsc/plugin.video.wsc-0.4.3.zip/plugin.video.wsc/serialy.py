# -*- coding: utf-8 -*-
# Vlastni uprava (2026-11): nabidka serialu z TMDB -> rady -> epizody -> hledani na Webshare.

import xbmc
import xbmcgui
import xbmcplugin
from xml.etree import ElementTree as ET

import filmy
import filmy_core as core


def menu(params):
    ws = filmy._ws()
    xbmcplugin.setPluginCategory(ws._handle, u'Seriály')
    li = xbmcgui.ListItem(label=u'Hledat seriál')
    li.setArt({'icon': 'DefaultAddonsSearch.png'})
    xbmcplugin.addDirectoryItem(ws._handle, ws.get_url(action='tv_search'), li, False)
    filmy._folder(u'Populární', 'DefaultTVShows.png', action='tv_list', kind='popular')
    filmy._folder(u'Nejlépe hodnocené', 'DefaultTVShows.png', action='tv_list', kind='top_rated')
    filmy._folder(u'Právě vysílané', 'DefaultRecentlyAddedEpisodes.png', action='tv_list', kind='on_the_air')
    filmy._folder(u'Žánry', 'DefaultGenre.png', action='tv_genres')
    filmy._folder(u'Moje seriály (ruční správce)', 'DefaultFolder.png', action='series')
    xbmcplugin.endOfDirectory(ws._handle)


def genres(params):
    ws = filmy._ws()
    tmdb = filmy._tmdb()
    if tmdb is None:
        xbmcplugin.endOfDirectory(ws._handle, succeeded=False)
        return
    try:
        for g in tmdb.tv_genres():
            filmy._folder(g['name'], 'DefaultGenre.png', action='tv_list', kind='genre', genre=g['id'])
    except Exception as e:
        filmy._error(e)
    xbmcplugin.endOfDirectory(ws._handle)


def search(params):
    ws = filmy._ws()
    what = ws.ask('')
    if what:
        xbmc.executebuiltin('Container.Update(' + ws.get_url(action='tv_list', kind='search', query=what) + ')')


def listing(params):
    ws = filmy._ws()
    tmdb = filmy._tmdb()
    if tmdb is None:
        xbmcplugin.endOfDirectory(ws._handle, succeeded=False)
        return
    kind = params.get('kind', 'popular')
    page = int(params.get('page', 1))
    extra = {}
    if 'genre' in params:
        extra['genre'] = params['genre']
    if 'query' in params:
        extra['query'] = params['query']
    try:
        shows, pages = tmdb.shows(kind, page=page, **extra)
    except Exception as e:
        filmy._error(e)
        xbmcplugin.endOfDirectory(ws._handle, succeeded=False)
        return
    xbmcplugin.setContent(ws._handle, 'tvshows')
    for m in shows:
        label = m['title']
        if m['year']:
            label += ' (' + m['year'] + ')'
        if m['rating']:
            label += u'  ★ %.1f' % m['rating']
        li = xbmcgui.ListItem(label=label)
        art = {}
        if m['poster']:
            art['poster'] = m['poster']
            art['thumb'] = m['poster']
        if m['fanart']:
            art['fanart'] = m['fanart']
        li.setArt(art)
        li.setInfo('video', {'title': label, 'plot': m['plot'], 'rating': m['rating']})
        import oblibene
        li.addContextMenuItems([oblibene.command('tv', m)])
        xbmcplugin.addDirectoryItem(ws._handle, ws.get_url(action='tv_seasons', id=m['id']), li, True)
    if page < pages:
        filmy._folder(u'Další strana (%d)' % (page + 1), 'DefaultAddonsSearch.png', action='tv_list', kind=kind,
                      page=page + 1, **extra)
    xbmcplugin.endOfDirectory(ws._handle)


def seasons(params):
    ws = filmy._ws()
    tmdb = filmy._tmdb()
    if tmdb is None:
        xbmcplugin.endOfDirectory(ws._handle, succeeded=False)
        return
    try:
        show, rows = tmdb.seasons(params['id'])
    except Exception as e:
        filmy._error(e)
        xbmcplugin.endOfDirectory(ws._handle, succeeded=False)
        return
    xbmcplugin.setPluginCategory(ws._handle, show['title'])
    xbmcplugin.setContent(ws._handle, 'seasons')
    for s in rows:
        label = u'%s  (%d dílů)' % (s['name'] or (u'Řada %d' % s['number']), s['count'])
        li = xbmcgui.ListItem(label=label)
        poster = s['poster'] or show['poster']
        if poster:
            li.setArt({'poster': poster, 'thumb': poster})
        li.setInfo('video', {'title': label, 'plot': s['plot'] or show['plot']})
        xbmcplugin.addDirectoryItem(ws._handle, ws.get_url(action='tv_episodes', id=params['id'], season=s['number'],
                                                           title=show['title'], orig=show['orig']), li, True)
    xbmcplugin.endOfDirectory(ws._handle)


def episodes(params):
    ws = filmy._ws()
    tmdb = filmy._tmdb()
    if tmdb is None:
        xbmcplugin.endOfDirectory(ws._handle, succeeded=False)
        return
    season = int(params['season'])
    try:
        rows = tmdb.episodes(params['id'], season)
    except Exception as e:
        filmy._error(e)
        xbmcplugin.endOfDirectory(ws._handle, succeeded=False)
        return
    xbmcplugin.setPluginCategory(ws._handle, u'%s – řada %d' % (params.get('title', ''), season))
    xbmcplugin.setContent(ws._handle, 'episodes')
    for e in rows:
        label = u'%d. %s' % (e['number'], e['name'])
        li = xbmcgui.ListItem(label=label)
        if e['still']:
            li.setArt({'thumb': e['still']})
        li.setInfo('video', {'title': label, 'plot': e['plot']})
        xbmcplugin.addDirectoryItem(ws._handle, ws.get_url(action='tv_find', title=params.get('title', ''),
                                                           orig=params.get('orig', ''), season=season,
                                                           episode=e['number']), li, True)
    xbmcplugin.endOfDirectory(ws._handle)


def find(params):
    """Najde epizodu na Webshare (S01E02 i 1x02, cesky i puvodni nazev)."""
    ws = filmy._ws()
    token = ws.revalidate()
    s, e = int(params['season']), int(params['episode'])
    titles = [t for t in (params.get('title', ''), params.get('orig', '')) if t]
    code = 'S%02dE%02d' % (s, e)
    xbmcplugin.setPluginCategory(ws._handle, (titles[0] if titles else '') + ' ' + code)
    queries = []
    for t in titles:
        for q in (t + ' ' + code, t + ' %dx%02d' % (s, e)):
            if core.norm(q) not in [core.norm(x) for x in queries]:
                queries.append(q)
    items = []
    for q in queries:
        try:
            response = ws.api('search', {'what': q, 'category': 'video', 'sort': '', 'limit': filmy.FIND_LIMIT,
                                         'offset': 0, 'wst': token, 'maybe_removed': 'true'})
            xml = ET.fromstring(response.content)
            if ws.is_ok(xml):
                items += [ws.todict(f) for f in xml.iter('file')]
        except Exception as ex:
            xbmc.log('WSC tv_find chyba: ' + str(ex), xbmc.LOGWARNING)
    rows = core.rank(items, titles=titles, strict=True, episode=(s, e))
    if not rows:
        ws.popinfo(u'Na Webshare jsem tento díl nenašel.', icon=xbmcgui.NOTIFICATION_WARNING, time=5000)
    meta = {'mshow': titles[0] if titles else '', 'morig': params.get('orig', ''), 'mseason': s, 'mepisode': e}
    for desc, item in rows:
        filmy.add_file(item, desc, meta=meta)
    if titles:
        filmy._folder(u'Hledat ručně: ' + titles[0] + ' ' + code, 'DefaultAddonsSearch.png', action='search',
                      what=titles[0] + ' ' + code, ask=1)
    xbmcplugin.endOfDirectory(ws._handle)
