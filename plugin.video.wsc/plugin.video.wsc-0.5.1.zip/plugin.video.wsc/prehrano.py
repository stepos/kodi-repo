# -*- coding: utf-8 -*-
# Vlastni uprava (2026-11): historie prehravani ulozena v datech doplnku; se sync.txt spolecna pro vsechna zarizeni
# (synchronizace.py). Kazdy radek nese 'u' = cas posledni zmeny (podle nej se slucuje).

import io
import json
import os
import time
import xbmc
import xbmcgui
import xbmcplugin

import filmy
import filmy_core as core

FILE = 'play_history.json'
LIMIT = 100


def _path():
    return os.path.join(filmy._ws()._profile, FILE)


def load():
    try:
        with io.open(_path(), 'r', encoding='utf8') as f:
            data = json.loads(f.read())
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save(rows):
    ws = filmy._ws()
    try:
        if not os.path.exists(ws._profile):
            os.makedirs(ws._profile)
        with io.open(_path(), 'w', encoding='utf8') as f:
            f.write(json.dumps(rows[:LIMIT], ensure_ascii=False))
    except Exception:
        pass


def remember(ident, name, size=None, meta=None):
    """Zapise prehrany soubor na zacatek historie (bez duplicit)."""
    if not ident:
        return
    old = [r for r in load() if r.get('ident') == ident]
    rows = [r for r in load() if r.get('ident') != ident]
    row = {'ident': ident, 'name': name or ident, 'size': size or '', 'time': int(time.time()), 'u': round(time.time(), 3)}
    if old:  # pozici z minula nechat
        for k in ('pos', 'total', 'done'):
            if k in old[0]:
                row[k] = old[0][k]
        if not row['size']:
            row['size'] = old[0].get('size', '')
        if not meta:
            meta = old[0].get('meta')
    if meta:
        row['meta'] = meta
    rows.insert(0, row)
    save(rows)


def position(ident):
    """Ulozena pozice v sekundach (0 = od zacatku)."""
    for r in load():
        if r.get('ident') == ident:
            try:
                return float(r.get('pos') or 0)
            except ValueError:
                return 0
    return 0


def store_position(ident, pos, total):
    rows = load()
    for r in rows:
        if r.get('ident') == ident:
            done = total > 0 and pos > total * 0.93
            r['pos'] = 0 if (done or pos < 60) else int(pos)
            r['total'] = int(total)
            r['done'] = bool(done)
            r['u'] = round(time.time(), 3)
            save(rows)
            return


def clock(seconds):
    seconds = int(seconds)
    return '%d:%02d:%02d' % (seconds // 3600, (seconds % 3600) // 60, seconds % 60)


def ask_resume(ident):
    """Zepta se, jestli pokracovat. Vrati pozici v sekundach nebo 0."""
    pos = position(ident)
    if pos < 60:
        return 0
    if xbmcgui.Dialog().yesno(u'Pokra\u010dovat?', u'Naposledy jsi skon\u010dil v \u010dase ' + clock(pos) + '.',
                              nolabel=u'Od za\u010d\u00e1tku', yeslabel=u'Pokra\u010dovat'):
        return pos
    return 0


SAVE_EVERY = 10   # s – jak casto se pozice uklada behem prehravani
PRED_KONCEM_S = 75  # s pred koncem dilu: nabidka dalsiho dilu
GONE_TICKS = 30   # s – jak dlouho se ceka, kdyz prehravani na chvili zmizi (zaseknuty stream, znovupripojeni)


def watch(ident, resume):
    """Bezi po spusteni prehravani: pripadne preskoci na ulozenou pozici a prubezne ji uklada.
    Vlastni uprava 2026-11-21 (Stepan: po restartu spatna pozice): ukladani kazdych 10 s, hned pri pauze
    (vcetne synchronizace na ostatni zarizeni), pri ukonceni Kodi, a kratky vypadek prehravani sledovani neukonci."""
    player = xbmc.Player()
    monitor = xbmc.Monitor()
    start = time.time()
    while not player.isPlayingVideo() and time.time() - start < 90:
        if monitor.waitForAbort(0.5):
            return
    if not player.isPlayingVideo():
        return
    try:
        playing = player.getPlayingFile()
    except Exception:
        return
    import synchronizace
    seeked = not resume
    pos = total = 0
    saved = time.time()
    paused_before = False
    gone = 0
    nabidnuto = False
    while True:
        if not player.isPlayingVideo():
            if gone == 0 and pos:
                store_position(ident, pos, total)  # zastaveno nebo zaseknute: hned ulozit posledni znamou pozici
            gone += 1
            if gone > GONE_TICKS:
                break
            if monitor.waitForAbort(1):
                store_position(ident, pos, total)
                return
            continue
        gone = 0
        try:
            if player.getPlayingFile() != playing:
                break
            now = player.getTime()
            total = player.getTotalTime()
        except Exception:
            if monitor.waitForAbort(1):
                break
            continue
        if not seeked:
            seeked = True
            if now < resume - 15:
                try:
                    player.seekTime(resume)
                except Exception:
                    pass
                now = resume
        pos = now
        if not nabidnuto and total > 300 and total - pos <= PRED_KONCEM_S:
            nabidnuto = True  # dalsi dil serialu ve stejnem formatu (dalsi_dil.py)
            store_position(ident, pos, total)
            try:
                row = next((r for r in load() if r.get('ident') == ident), None)
                if row and (row.get('meta') or {}).get('mepisode'):
                    import dalsi_dil
                    dalsi_dil.nabidni(row)
            except Exception as ex:
                xbmc.log('WSC dalsi dil: %s' % ex, xbmc.LOGWARNING)
            continue
        paused = xbmc.getCondVisibility('Player.Paused')
        if paused and not paused_before:
            store_position(ident, pos, total)
            saved = time.time()
            try:
                synchronizace.sync()  # pauza: pozice hned i na ostatni zarizeni
            except Exception:
                pass
        elif time.time() - saved >= SAVE_EVERY:
            store_position(ident, pos, total)
            saved = time.time()
        paused_before = paused
        if monitor.waitForAbort(1):
            store_position(ident, pos, total)  # Kodi se ukoncuje: ulozit hned, bez site
            return
    store_position(ident, pos, total)
    synchronizace.sync()  # pozice a nove prehrany soubor na ostatni zarizeni


def _nahled_dilu(tmdb, meta):
    """Dil serialu: plakat a pozadi serialu, nazev a popis dilu. Stare zaznamy bez mtv: serial podle nazvu."""
    tv = meta.get('mtv')
    if not tv:
        for q in (meta.get('mshow'), meta.get('morig')):
            if q:
                res = tmdb.get('/search/tv', query=q).get('results', [])
                if res:
                    tv = res[0]['id']
                    break
    if not tv:
        return {}
    show = tmdb.show(tmdb.get('/tv/%s' % tv))
    s, e = int(meta['mseason']), int(meta['mepisode'])
    ep = {}
    try:
        ep = tmdb.get('/tv/%s/season/%d/episode/%d' % (tv, s, e))
    except Exception:
        pass
    nazev = u'%s – S%02dE%02d' % (show['title'], s, e)
    if ep.get('name'):
        nazev += u' ' + ep['name']
    return {'poster': show.get('poster') or '', 'fanart': show.get('fanart') or '', 'title': nazev, 'year': '',
            'plot': ep.get('overview') or show.get('plot') or '', 'rating': float(ep.get('vote_average') or 0)}


def _doplnit_nahledy(rows):
    """Plakat, pozadi a popis z TMDB pro radky historie s cislem filmu (mtmdb); jednou stazene se ulozi do 'art'.
    Vlastni uprava 2026-11-21 (Stepan: nahled i v Pokracovat v sledovani)."""
    def ma_co(m):
        return m.get('mtmdb') or (m.get('mseason') and m.get('mepisode') and (m.get('mtv') or m.get('mshow') or m.get('morig')))
    chybi = [r for r in rows if ma_co(r.get('meta') or {}) and 'art' not in r]
    if not chybi:
        return
    ws = filmy._ws()
    key = ws._addon.getSetting('tmdb_token').strip()
    if not key:
        try:
            with io.open(os.path.join(ws._profile, filmy.KEY_FILE), 'r', encoding='utf8') as f:
                key = f.read().strip()
        except Exception:
            return
    import requests
    tmdb = core.Tmdb(key, requests)
    zmena = False
    for r in chybi[:20]:
        try:
            meta = r['meta']
            if meta.get('mtmdb'):
                m = tmdb.movie(tmdb.get('/movie/%s' % meta['mtmdb']))
                r['art'] = {'poster': m['poster'], 'fanart': m['fanart'], 'plot': m['plot'], 'title': m['title'],
                            'year': m['year'], 'rating': m['rating']}
            else:
                r['art'] = _nahled_dilu(tmdb, meta)
            zmena = True
        except Exception:
            pass
    if zmena:
        vse = load()
        podle = dict((r['ident'], r.get('art')) for r in chybi if r.get('art'))
        for r in vse:
            if r.get('ident') in podle:
                r['art'] = podle[r['ident']]
        save(vse)


def menu(params):
    ws = filmy._ws()
    jen = bool(params.get('rozkoukane'))  # Pokracovat v sledovani: jen rozkoukane (vlastni uprava 2026-11)
    xbmcplugin.setPluginCategory(ws._handle, u'Pokračovat v sledování' if jen else u'Historie přehrávání')
    import synchronizace
    if 'remove' in params:
        save([r for r in load() if r.get('ident') != params['remove']])
        synchronizace.smazano('history', params['remove'])
    if 'clear' in params:
        save([])
        synchronizace.historie_vymazana()
    synchronizace.sync()
    rows = load()
    if jen:
        rows = core.rozkoukane(rows)
        if not rows:
            li = xbmcgui.ListItem(label=u'Nic rozkoukaného – filmy, které nedokoukáš, se objeví tady')
            xbmcplugin.addDirectoryItem(ws._handle, ws.get_url(action='played', rozkoukane=1), li, False)
    try:
        _doplnit_nahledy(rows)  # bez internetu/klice se seznam ukaze i tak
    except Exception:
        pass
    for r in rows:
        when = time.strftime('%d.%m. %H:%M', time.localtime(r.get('time', 0)))
        item = {'ident': r['ident'], 'name': r['name'], 'size': r.get('size') or ''}
        state = ''
        if r.get('done'):
            state = u'dokoukáno, '
        elif r.get('pos') and r.get('total'):
            state = u'%d %%, ' % round(100.0 * r['pos'] / r['total'])
        text = core.label(item) + u'  (' + state + when + u')'
        li = xbmcgui.ListItem(label=text)
        a = r.get('art') or {}
        if a.get('poster'):
            li.setArt({'poster': a['poster'], 'fanart': a.get('fanart') or ''})  # bez 'thumb': jinak dlazdice
        nazev = a.get('title') or (r.get('meta') or {}).get('mtitle') or ''
        if nazev and a.get('year'):
            nazev += ' (%s)' % a['year']
        li.setInfo('video', {'title': nazev or text, 'plot': (state + when + '\n\n' if state else '') + (a.get('plot') or ''),
                             'rating': a.get('rating') or 0})
        li.setProperty('IsPlayable', 'true')
        li.addContextMenuItems([(u'Odebrat z historie', 'Container.Update(' + ws.get_url(action='played', remove=r['ident'], **({'rozkoukane': 1} if jen else {})) + ')')])
        xbmcplugin.addDirectoryItem(ws._handle, ws.get_url(action='play', ident=r['ident'], name=r['name'], size=r.get('size') or '',
                                                           **(r.get('meta') or {})), li, False)
    if rows and not jen:
        filmy._folder(u'Smazat celou historii', 'DefaultAddonNone.png', action='played', clear=1)
    xbmcplugin.endOfDirectory(ws._handle, updateListing=('remove' in params or 'clear' in params))
