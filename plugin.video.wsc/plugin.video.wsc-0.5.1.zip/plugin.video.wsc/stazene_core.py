# -*- coding: utf-8 -*-
# Vlastni uprava (2026-11): stazene filmy – logika bez Kodi (testuje testy/test_stazene.py).
import io
import json
import os
import re

SLOZKA = 'Stazene'          # vychozi slozka v datech doplnku, kdyz neni nastavena jina
CAST = '.part'              # rozstahovany soubor (po dokonceni se prejmenuje)
VIDEO = ('.mkv', '.mp4', '.avi', '.m4v', '.mov', '.ts', '.wmv', '.webm', '.mpg', '.mpeg', '.flv')
REZERVA = 500 * 1024 * 1024  # kolik volneho mista nechat po stazeni


def bezpecny_nazev(name):
    """Nazev souboru bez znaku, ktere nejdou do cesty."""
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', ' ', name or '').strip(' .')
    return name or 'film'


def velikost(b):
    b = float(b or 0)
    for jed in ('B', 'KB', 'MB', 'GB'):
        if b < 1024 or jed == 'GB':
            return (('%.1f' % b).replace('.', ',') if jed == 'GB' else '%d' % b) + ' ' + jed
        b /= 1024.0


def meta_cesta(part):
    return part + '.json'


def uloz_meta(part, ident, total):
    with io.open(meta_cesta(part), 'w', encoding='utf8') as f:
        f.write(json.dumps({'ident': ident, 'total': total}))


def nacti_meta(part):
    try:
        with io.open(meta_cesta(part), 'r', encoding='utf8') as f:
            return json.loads(f.read())
    except Exception:
        return {}


def seznam(slozka):
    """Stazene a rozstahovane filmy, nejnovejsi prvni → [{'name','path','size','hotovo','ident','total'}]."""
    out = []
    if not os.path.isdir(slozka):
        return out
    for f in os.listdir(slozka):
        p = os.path.join(slozka, f)
        if not os.path.isfile(p):
            continue
        if f.endswith(CAST):
            m = nacti_meta(p)
            out.append({'name': f[:-len(CAST)], 'path': p, 'size': os.path.getsize(p), 'hotovo': False,
                        'ident': m.get('ident'), 'total': m.get('total') or 0, 'mtime': os.path.getmtime(p)})
        elif f.lower().endswith(VIDEO):
            out.append({'name': f, 'path': p, 'size': os.path.getsize(p), 'hotovo': True,
                        'ident': None, 'total': 0, 'mtime': os.path.getmtime(p)})
    out.sort(key=lambda x: -x['mtime'])
    return out


def popisek(polozka):
    """Dulezite udaje na zacatek radku (Stepan hur vidi)."""
    if polozka['hotovo']:
        return velikost(polozka['size']) + ' · ' + polozka['name']
    if polozka['total']:
        pct = int(polozka['size'] * 100 / polozka['total'])
        return u'Nedostaženo %d %% · %s' % (pct, polozka['name'])
    return u'Nedostaženo · ' + velikost(polozka['size']) + ' · ' + polozka['name']


def odkud(existujici, status):
    """Odkud se zapisuje: navazani (206 = server poslal jen zbytek) nebo od zacatku (cokoliv jineho)."""
    return existujici if existujici and status == 206 else 0


def dost_mista(volno, potreba, uz_stazeno=0):
    return volno - max(0, (potreba or 0) - uz_stazeno) >= REZERVA


def stahuje_se(mtime, ted=None):
    """Rozstahovany soubor se zmenil v posledni pul minute → stahovani prave bezi (nespoustet podruhe)."""
    import time
    return (ted or time.time()) - mtime < 30
