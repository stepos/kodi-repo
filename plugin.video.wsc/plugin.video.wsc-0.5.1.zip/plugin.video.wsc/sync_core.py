# -*- coding: utf-8 -*-
# Vlastni uprava (2026-11): synchronizace historie prehravani a oblibenych mezi zarizenimi pres soukromy GitHub gist.
# Cista logika bez Kodi (testuje testy/test_sync.py). Kazdy radek nese cas posledni zmeny 'u'; smazane polozky
# zustavaji jako „nahrobky“ (cas smazani), aby se z jineho zarizeni nevratily. Slucuje se podle casu: novejsi vyhrava.

import json
import time

SOUBOR = 'wsc-sync.json'       # nazev souboru v gistu
LIMIT = 100                    # radku historie (stejne jako prehrano.LIMIT)
NAHROBKY_DNI = 120             # jak dlouho si pamatovat smazane polozky
API = 'https://api.github.com/gists/'


def zmena(row):
    """Cas posledni zmeny radku (starsi radky bez 'u' → cas prehrani, jinak 0)."""
    try:
        return float(row.get('u') or row.get('time') or 0)
    except (TypeError, ValueError):
        return 0.0


def klic_historie(row):
    return row.get('ident') or ''


def klic_oblibene(row):
    # stejne jako oblibene.key
    if row.get('kind') == 'tv':
        return 'tv:' + str(row.get('id', ''))
    return 'film:' + (row.get('title', '') + '|' + row.get('year', '')).lower()


def prazdny():
    return {'v': 1, 'history': [], 'fav': [], 'deleted': {'history': {}, 'fav': {}, 'history_clear': 0}}


def normalizuj(doc):
    """Cokoli (i poskozeny obsah gistu) → platny dokument."""
    d = prazdny()
    if not isinstance(doc, dict):
        return d
    for k in ('history', 'fav'):
        if isinstance(doc.get(k), list):
            d[k] = [r for r in doc[k] if isinstance(r, dict)]
    dl = doc.get('deleted')
    if isinstance(dl, dict):
        for k in ('history', 'fav'):
            if isinstance(dl.get(k), dict):
                d['deleted'][k] = dict((a, float(b)) for a, b in dl[k].items() if isinstance(b, (int, float)))
        if isinstance(dl.get('history_clear'), (int, float)):
            d['deleted']['history_clear'] = float(dl['history_clear'])
    return d


def _sluc_radky(a, b, klic, smazane, od=0.0):
    nej = {}
    for r in list(a) + list(b):
        k = klic(r)
        if not k:
            continue
        if k not in nej or zmena(r) > zmena(nej[k]):
            nej[k] = r
    return [r for k, r in nej.items() if zmena(r) > smazane.get(k, 0) and zmena(r) > od]


def sluc(a, b, ted=None):
    """Slouci dva dokumenty (mistni + z gistu). Vysledek nezavisi na poradi."""
    ted = time.time() if ted is None else ted
    a, b = normalizuj(a), normalizuj(b)
    d = prazdny()
    hranice = ted - NAHROBKY_DNI * 86400
    for k in ('history', 'fav'):
        sm = {}
        for x in (a, b):
            for kk, t in x['deleted'][k].items():
                if t > hranice and t > sm.get(kk, 0):
                    sm[kk] = t
        d['deleted'][k] = sm
    d['deleted']['history_clear'] = max(a['deleted']['history_clear'], b['deleted']['history_clear'])
    h = _sluc_radky(a['history'], b['history'], klic_historie, d['deleted']['history'], d['deleted']['history_clear'])
    h.sort(key=lambda r: (-float(r.get('time') or 0), klic_historie(r)))
    d['history'] = h[:LIMIT]
    f = _sluc_radky(a['fav'], b['fav'], klic_oblibene, d['deleted']['fav'])
    f.sort(key=lambda r: (-zmena(r), klic_oblibene(r)))
    d['fav'] = f
    return d


def stejne(a, b):
    return json.dumps(normalizuj(a), sort_keys=True) == json.dumps(normalizuj(b), sort_keys=True)


def nacti_klic(text):
    """Obsah sync.txt: 1. radek token GitHubu (jen pravo Gists), 2. radek ID gistu. Neplatny → None."""
    radky = [r.strip() for r in (text or '').splitlines() if r.strip()]
    if len(radky) < 2 or len(radky[0]) < 20 or not radky[1].isalnum():
        return None
    return radky[0], radky[1]


def hlavicky(token):
    return {'Authorization': 'Bearer ' + token, 'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'kodi-wsc-sync'}


def z_gistu(odpoved):
    """JSON odpovedi GET /gists/{id} → dokument (chybi-li soubor, prazdny)."""
    try:
        return normalizuj(json.loads(odpoved['files'][SOUBOR]['content']))
    except Exception:
        return prazdny()


def do_gistu(doc):
    return {'files': {SOUBOR: {'content': json.dumps(normalizuj(doc), ensure_ascii=False, sort_keys=True)}}}
