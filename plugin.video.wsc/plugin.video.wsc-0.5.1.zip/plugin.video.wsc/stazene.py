# -*- coding: utf-8 -*-
# Vlastni uprava (2026-11): stahovani filmu do zarizeni a nabidka Stazene filmy (prehrani bez internetu).
# Prerusene stahovani (vypadek signalu, zavreni Kodi) jde dokoncit – navazuje tam, kde skoncilo.
import io
import os
import shutil
import traceback
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

import stazene_core as core


def _ws():
    import yawsp
    return yawsp


def slozka():
    """Nastavena slozka, jinak Stazene v datech doplnku (vytvori se)."""
    ws = _ws()
    where = ws._addon.getSetting('dfolder')
    if where:
        where = xbmcvfs.translatePath(where)
    else:
        where = os.path.join(ws._profile, core.SLOZKA)
    if not os.path.isdir(where):
        try:
            os.makedirs(where)
        except Exception:
            pass
    return where


def download(params):
    ws = _ws()
    ident = params['ident']
    where = slozka()
    if not os.path.isdir(where):
        ws.popinfo(u'Složka pro stahování není dostupná', icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
        return
    token = ws.revalidate()
    name = ident
    dlg = None
    try:
        info = ws.getinfo(ident, token)
        name = core.bezpecny_nazev(info.find('name').text)
        try:
            celkem = int(info.find('size').text)
        except Exception:
            celkem = 0
        cil = os.path.join(where, name)
        part = cil + core.CAST
        if os.path.exists(cil):
            ws.popinfo(u'Už staženo: ' + name)
            return
        uz = os.path.getsize(part) if os.path.exists(part) else 0
        if uz and core.stahuje_se(os.path.getmtime(part)):
            ws.popinfo(u'Už se stahuje: ' + name)
            return
        if celkem and not core.dost_mista(shutil.disk_usage(where).free, celkem, uz):
            xbmcgui.Dialog().ok(u'Málo místa', u'Na stažení není dost volného místa (potřeba %s).' % core.velikost(celkem - uz))
            return
        core.uloz_meta(part, ident, celkem)
        link = ws.getlink(ident, token, 'file_download')
        hlav = {'Range': 'bytes=%d-' % uz} if uz else {}
        response = ws._session.get(link, stream=True, headers=hlav, timeout=60)
        start = core.odkud(uz, response.status_code)
        delka = response.headers.get('content-length')
        total = start + int(delka) if delka else celkem
        dlg = xbmcgui.DialogProgressBG()
        dlg.create(u'Stahuji', name)
        mon = xbmc.Monitor()
        hotovo, posledni = start, -1
        with io.open(part, 'ab' if start else 'wb') as bf:
            for data in response.iter_content(chunk_size=256 * 1024):
                if mon.abortRequested():
                    raise IOError('Kodi se ukoncuje')
                bf.write(data)
                hotovo += len(data)
                if total:
                    pct = int(hotovo * 100 / total)
                    if pct != posledni:
                        dlg.update(pct, u'Stahuji %d %%' % pct, name)
                        posledni = pct
        if total and hotovo < total:
            raise IOError('nedostazeno')
        dlg.close()
        dlg = None
        os.rename(part, cil)
        try:
            os.remove(core.meta_cesta(part))
        except Exception:
            pass
        ws.popinfo(u'Staženo: ' + name, sound=True)
    except Exception:
        traceback.print_exc()
        if dlg:
            dlg.close()
        ws.popinfo(u'Stahování přerušeno – dokončíš ho ve Stažených filmech: ' + name,
                   icon=xbmcgui.NOTIFICATION_WARNING, sound=True)


def menu(params):
    ws = _ws()
    handle = ws._handle
    polozky = core.seznam(slozka())
    if not polozky:
        li = xbmcgui.ListItem(label=u'Zatím nic – u filmu podrž/otevři nabídku a zvol „Stáhnout soubor“')
        xbmcplugin.addDirectoryItem(handle, ws.get_url(action='downloads'), li, False)
    for p in polozky:
        li = xbmcgui.ListItem(label=core.popisek(p))
        li.setInfo('video', {'title': p['name']})
        smazat = (u'Smazat stažený film', 'RunPlugin(' + ws.get_url(action='dl_delete', path=p['path']) + ')')
        if p['hotovo']:
            li.setArt({'icon': 'DefaultVideo.png'})
            li.addContextMenuItems([smazat])
            # prima cesta k souboru: Kodi prehraje bez internetu a samo si pamatuje pozici
            xbmcplugin.addDirectoryItem(handle, p['path'], li, False)
        else:
            li.setArt({'icon': 'DefaultAddonsUpdates.png'})
            li.addContextMenuItems([smazat])
            url = ws.get_url(action='download', ident=p['ident']) if p['ident'] else ws.get_url(action='downloads')
            xbmcplugin.addDirectoryItem(handle, url, li, False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def delete(params):
    path = params.get('path') or ''
    if not path.startswith(slozka()) or not os.path.exists(path):
        return
    jmeno = os.path.basename(path)
    if not xbmcgui.Dialog().yesno(u'Smazat stažený film?', jmeno + u'\n\nUvolní místo v zařízení. Na Webshare film zůstane.'):
        return
    for f in (path, core.meta_cesta(path)):
        try:
            os.remove(f)
        except Exception:
            pass
    xbmc.executebuiltin('Container.Refresh')
