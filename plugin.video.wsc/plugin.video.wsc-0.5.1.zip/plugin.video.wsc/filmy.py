# -*- coding: utf-8 -*-
# Vlastni uprava (2026-11): nabidka filmu z TMDB, po vyberu filmu hledani na Webshare.

import io
import os
import requests
import xbmc
import xbmcgui
import xbmcplugin
from xml.etree import ElementTree as ET

import filmy_core as core

KEY_FILE = 'tmdb_key.txt'
FIND_LIMIT = 100


def _ws():
    import yawsp
    return yawsp


def _tmdb():
    ws = _ws()
    key = ws._addon.getSetting('tmdb_token').strip()
    if not key:
        try:
            with io.open(os.path.join(ws._profile, KEY_FILE), 'r', encoding='utf8') as f:
                key = f.read().strip()
        except Exception:
            key = ''
    if not key:
        xbmcgui.Dialog().ok('Filmy', u'Chybí klíč TMDB. Zadej ho v Nastavení doplňku '
                                     u'(TMDB → API Token). Klíč je zdarma na themoviedb.org.')
        return None
    return core.Tmdb(key, requests)


def _folder(label, icon, **url):
    ws = _ws()
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': icon})
    xbmcplugin.addDirectoryItem(ws._handle, ws.get_url(**url), li, True)


def menu(params):
    ws = _ws()
    xbmcplugin.setPluginCategory(ws._handle, 'Filmy')
    # neni slozka: jen otevre klavesnici a pak prepne seznam (stejne jako polozka Nastaveni)
    li = xbmcgui.ListItem(label=u'Hledat film')
    li.setArt({'icon': 'DefaultAddonsSearch.png'})
    xbmcplugin.addDirectoryItem(ws._handle, ws.get_url(action='film_search'), li, False)
    _folder(u'Novinky v kinech', 'DefaultRecentlyAddedMovies.png', action='film_list', kind='now_playing')
    _folder(u'Populární', 'DefaultMovies.png', action='film_list', kind='popular')
    _folder(u'Nejlépe hodnocené', 'DefaultMovies.png', action='film_list', kind='top_rated')
    _folder(u'Připravované', 'DefaultYear.png', action='film_list', kind='upcoming')
    _folder(u'Žánry', 'DefaultGenre.png', action='film_genres')
    xbmcplugin.endOfDirectory(ws._handle)


def genres(params):
    ws = _ws()
    tmdb = _tmdb()
    if tmdb is None:
        xbmcplugin.endOfDirectory(ws._handle, succeeded=False)
        return
    try:
        for g in tmdb.genres():
            _folder(g['name'], 'DefaultGenre.png', action='film_list', kind='genre', genre=g['id'])
    except Exception as e:
        _error(e)
    xbmcplugin.endOfDirectory(ws._handle)


def search(params):
    ws = _ws()
    what = ws.ask('')
    if what:
        xbmc.executebuiltin('Container.Update(' + ws.get_url(action='film_list', kind='search', query=what) + ')')


def listing(params):
    ws = _ws()
    tmdb = _tmdb()
    if tmdb is None:
        xbmcplugin.endOfDirectory(ws._handle, succeeded=False)
        return
    kind = params.get('kind', 'popular')
    page = int(params.get('page', 1))
    extra = {}
    if 'genre' in params:
        extra['genre'] = params['genre']
    if 'query' in params:
        extra['query'] = params['query']
    try:
        movies, pages = tmdb.movies(kind, page=page, **extra)
    except Exception as e:
        _error(e)
        xbmcplugin.endOfDirectory(ws._handle, succeeded=False)
        return
    xbmcplugin.setContent(ws._handle, 'movies')
    for m in movies:
        label = m['title']
        if m['year']:
            label += ' (' + m['year'] + ')'
        if m['rating']:
            label += u'  ★ %.1f' % m['rating']
        li = xbmcgui.ListItem(label=label)
        art = {}
        if m['poster']:
            art['poster'] = m['poster']
            art['thumb'] = m['poster']
        if m['fanart']:
            art['fanart'] = m['fanart']
        li.setArt(art)
        info = {'title': label, 'plot': m['plot'], 'rating': m['rating']}
        if m['year']:
            info['year'] = int(m['year'])
        li.setInfo('video', info)
        import oblibene
        li.addContextMenuItems([oblibene.command('film', m)])
        xbmcplugin.addDirectoryItem(ws._handle, ws.get_url(action='film_find', title=m['title'], orig=m['orig'],
                                                           year=m['year'], tmdb=m['id']), li, True)
    if page < pages:
        _folder(u'Další strana (%d)' % (page + 1), 'DefaultAddonsSearch.png', action='film_list', kind=kind,
                page=page + 1, **extra)
    xbmcplugin.endOfDirectory(ws._handle)


def find(params):
    """Najde vybrany film na Webshare a seradi soubory od nejlepsiho."""
    ws = _ws()
    token = ws.revalidate()
    title = params.get('title', '')
    orig = params.get('orig', '')
    year = params.get('year', '')
    xbmcplugin.setPluginCategory(ws._handle, title)
    titles = [t for t in (title, orig) if t]
    queries = []
    for t in titles:
        q = (t + ' ' + year).strip()
        if core.norm(q) not in [core.norm(x) for x in queries]:
            queries.append(q)
    items = []
    for q in queries:
        try:
            response = ws.api('search', {'what': q, 'category': 'video', 'sort': '', 'limit': FIND_LIMIT,
                                         'offset': 0, 'wst': token, 'maybe_removed': 'true'})
            xml = ET.fromstring(response.content)
            if ws.is_ok(xml):
                items += [ws.todict(f) for f in xml.iter('file')]
        except Exception as e:
            xbmc.log('WSC film_find chyba: ' + str(e), xbmc.LOGWARNING)
    rows = core.rank(items, titles=titles, year=year, strict=True)
    if not rows:
        ws.popinfo(u'Na Webshare jsem tento film nenašel.', icon=xbmcgui.NOTIFICATION_WARNING, time=5000)
    meta = {'mtitle': title, 'morig': orig, 'myear': year, 'mtmdb': params.get('tmdb', '')}
    for desc, item in rows:
        add_file(item, desc, meta=meta)
    _folder(u'Hledat ručně: ' + title, 'DefaultAddonsSearch.png', action='search', what=title, ask=1)
    xbmcplugin.endOfDirectory(ws._handle)


META_KEYS = ('mtitle', 'morig', 'myear', 'mshow', 'mseason', 'mepisode', 'mtmdb', 'mtmdbep', 'mtv')


def meta_of(params):
    """Udaje o filmu/dilu, ktere se nesou v adrese prehrani (kvuli titulkum)."""
    return dict((k, params[k]) for k in META_KEYS if params.get(k))


def apply_meta(li, params):
    """Preda prehravaci nazev, rok a dil, aby doplnky na titulky hledaly spravny film."""
    m = meta_of(params)
    if not m:
        return
    show = m.get('mshow')
    title = m.get('mtitle') or show
    year = int(m['myear']) if str(m.get('myear', '')).isdigit() else 0
    try:
        tag = li.getVideoInfoTag()
        tag.setMediaType('episode' if show else 'movie')
        tag.setTitle(title)
        if m.get('morig'):
            tag.setOriginalTitle(m['morig'])
        if year:
            tag.setYear(year)
        if show:
            tag.setTvShowTitle(show)
            tag.setSeason(int(m.get('mseason') or 0))
            tag.setEpisode(int(m.get('mepisode') or 0))
        # cislo filmu/dilu z TMDB: doplnky na titulky podle nej hledaji presne (ne podle slov v nazvu)
        if str(m.get('mtmdb', '')).isdigit():
            tag.setUniqueIDs({'tmdb': str(m['mtmdb'])}, 'tmdb')
        elif str(m.get('mtmdbep', '')).isdigit():
            tag.setUniqueIDs({'tmdbepisode': str(m['mtmdbep'])}, 'tmdbepisode')
    except Exception:
        info = {'title': title, 'mediatype': 'episode' if show else 'movie'}
        if m.get('morig'):
            info['originaltitle'] = m['morig']
        if year:
            info['year'] = year
        if show:
            info.update({'tvshowtitle': show, 'season': int(m.get('mseason') or 0), 'episode': int(m.get('mepisode') or 0)})
        li.setInfo('video', info)


def add_file(item, desc, commands=None, meta=None):
    """Prida prehratelny soubor; popisek dela yawsp.labelize: [jazyk] rozliseni · velikost · nazev."""
    ws = _ws()
    li = ws.tolistitem(item, commands or [])
    xbmcplugin.addDirectoryItem(ws._handle, ws.get_url(action='play', ident=item['ident'], name=item['name'],
                                                       size=item.get('size') or '', **(meta or {})), li, False)


def _error(e):
    xbmc.log('WSC TMDB chyba: ' + str(e), xbmc.LOGWARNING)
    msg = u'TMDB neodpovědělo.'
    if '401' in str(e):
        msg = u'TMDB odmítlo klíč (401). Zkontroluj ho v Nastavení.'
    _ws().popinfo(msg, icon=xbmcgui.NOTIFICATION_WARNING, time=6000)
