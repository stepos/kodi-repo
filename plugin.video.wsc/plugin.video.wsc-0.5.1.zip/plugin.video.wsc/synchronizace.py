# -*- coding: utf-8 -*-
# Vlastni uprava (2026-11): historie a oblibene spolecne pro vsechna zarizeni (soukromy GitHub gist).
# Zapne se jen souborem sync.txt v datech doplnku (token + ID gistu, nahrava nastroje/nahraj-sync-klic.sh).
# Bez nej se nic nedeje. Chyby site se jen zapisou do zaznamu Kodi – doplnek funguje dal s mistnimi daty.

import io
import json
import os
import time
import requests
import xbmc

import filmy
import sync_core as core

KLIC = 'sync.txt'
SMAZANE = 'smazane.json'
CAS = 6  # sekund na odpoved GitHubu


def _cesta(jmeno):
    return os.path.join(filmy._ws()._profile, jmeno)


def _cti(jmeno, vychozi):
    try:
        with io.open(_cesta(jmeno), 'r', encoding='utf8') as f:
            return json.loads(f.read())
    except Exception:
        return vychozi


def _pis(jmeno, data):
    try:
        prof = filmy._ws()._profile
        if not os.path.exists(prof):
            os.makedirs(prof)
        with io.open(_cesta(jmeno), 'w', encoding='utf8') as f:
            f.write(json.dumps(data, ensure_ascii=False))
    except Exception:
        pass


def zapnuto():
    try:
        with io.open(_cesta(KLIC), 'r', encoding='utf8') as f:
            return core.nacti_klic(f.read())
    except Exception:
        return None


def _mistni():
    import oblibene
    import prehrano
    return core.normalizuj({'history': prehrano.load(), 'fav': oblibene.load(),
                            'deleted': _cti(SMAZANE, {})})


def _uloz_mistni(doc):
    import oblibene
    import prehrano
    prehrano.save(doc['history'])
    oblibene.save(doc['fav'])
    _pis(SMAZANE, doc['deleted'])


def smazano(druh, klic):
    """Zapamatuje smazani polozky ('history' / 'fav'), aby se z jineho zarizeni nevratila."""
    d = core.normalizuj({'deleted': _cti(SMAZANE, {})})['deleted']
    d[druh][klic] = time.time()
    _pis(SMAZANE, d)


def historie_vymazana():
    d = core.normalizuj({'deleted': _cti(SMAZANE, {})})['deleted']
    d['history_clear'] = time.time()
    _pis(SMAZANE, d)


def sync():
    """Stahne gist, slouci s mistnimi daty, ulozi mistne a pripadne posle zpet. Vraci True, kdyz se neco zmenilo."""
    klic = zapnuto()
    if not klic:
        return False
    token, gist = klic
    try:
        r = requests.get(core.API + gist, headers=core.hlavicky(token), timeout=CAS)
        r.raise_for_status()
        vzdaleny = core.z_gistu(r.json())
        mistni = _mistni()
        spolecny = core.sluc(mistni, vzdaleny)
        zmena = not core.stejne(spolecny, mistni)
        if zmena:
            _uloz_mistni(spolecny)
        if not core.stejne(spolecny, vzdaleny):
            p = requests.patch(core.API + gist, headers=core.hlavicky(token), json=core.do_gistu(spolecny), timeout=CAS)
            p.raise_for_status()
        return zmena
    except Exception as e:
        # bez tokenu v textu: requests ho do chyby nedava, hlavicky se nevypisuji
        xbmc.log('WSC synchronizace: ' + type(e).__name__ + ' ' + str(getattr(getattr(e, 'response', None), 'status_code', '')),
                 xbmc.LOGWARNING)
        return False
