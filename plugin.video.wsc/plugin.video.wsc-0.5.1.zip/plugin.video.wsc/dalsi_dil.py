# -*- coding: utf-8 -*-
# Vlastni uprava (2026-11-21, Stepan): ke konci dilu serialu nabidne dalsi dil ve stejnem formatu
# (jazyk, rozliseni, stejne vydani/skupina, podobna velikost). Logika vyberu je v filmy_core (testy/test_core.py).
import io
import os
import xbmc
import xbmcgui

import filmy
import filmy_core as core

PRED_KONCEM = 75  # s pred koncem dilu se zepta
CEKAT = 40        # s, jak dlouho dotaz ceka na odpoved (pak zmizi, nic se nepusti)


def _tmdb():
    ws = filmy._ws()
    key = ws._addon.getSetting('tmdb_token').strip()
    if not key:
        try:
            with io.open(os.path.join(ws._profile, filmy.KEY_FILE), 'r', encoding='utf8') as f:
                key = f.read().strip()
        except Exception:
            return None
    import requests
    return core.Tmdb(key, requests)


def najdi(row):
    """Pro radek historie prave sledovaneho dilu vrati (rada, dil, nazev dilu, desc, item, meta) dalsiho dilu, nebo None."""
    meta = dict(row.get('meta') or {})
    if not (meta.get('mseason') and meta.get('mepisode')):
        return None
    titles = [t for t in (meta.get('mshow'), meta.get('morig')) if t]
    if not titles:
        return None
    s, e = int(meta['mseason']), int(meta['mepisode'])
    tmdb = _tmdb()
    pocet, jmena = None, {}
    if tmdb and meta.get('mtv'):
        try:
            dily = tmdb.episodes(meta['mtv'], s)
            pocet = len(dily) or None
            jmena = dict(((s, d['number']), d['name']) for d in dily)
        except Exception:
            pass
    ws = filmy._ws()
    token = ws.revalidate()
    import serialy
    kandidati = [core.dalsi_dil(s, e, pocet)]
    if not pocet:
        kandidati.append((s + 1, 1))  # nevime, kolik ma rada dilu: kdyz E+1 neni, zkusit dalsi radu
    for s2, e2 in kandidati:
        rows = serialy.hledej_dil(ws, token, titles, s2, e2)
        vyber = core.vyber_stejny_format(row.get('name') or '', row.get('size'), rows, titles)
        if vyber:
            if (s2, e2) not in jmena and tmdb and meta.get('mtv') and s2 != s:
                try:
                    jmena.update(((s2, d['number']), d['name']) for d in tmdb.episodes(meta['mtv'], s2))
                except Exception:
                    pass
            meta2 = dict(meta, mseason=s2, mepisode=e2)
            meta2.pop('mtmdbep', None)
            return s2, e2, jmena.get((s2, e2), ''), vyber[0], vyber[1], meta2
    return None


def nabidni(row):
    """Zepta se, jestli pustit dalsi dil; pri Ano ho rovnou spusti. Vraci True, kdyz se spustil."""
    nalez = najdi(row)
    if not nalez:
        return False
    s2, e2, jmeno, desc, item, meta2 = nalez
    ws = filmy._ws()
    radek1 = u'S%02dE%02d %s' % (s2, e2, jmeno)
    radek2 = core.label(item, desc)
    if not xbmcgui.Dialog().yesno(u'Další díl', radek1.strip() + u'\n' + radek2, nolabel=u'Ne', yeslabel=u'Pustit',
                                  autoclose=CEKAT * 1000):
        return False
    url = ws.get_url(action='play', ident=item['ident'], name=item.get('name') or '', size=item.get('size') or '', **meta2)
    xbmc.executebuiltin('PlayMedia(%s)' % url)
    return True
