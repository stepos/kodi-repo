# -*- coding: utf-8 -*-
# Vlastni uprava (2026-11): oblibene filmy a serialy primo v doplnku (ulozeno v datech doplnku); se sync.txt
# spolecne pro vsechna zarizeni (synchronizace.py). 'u' = cas pridani.

import io
import time
import json
import os
import xbmc
import xbmcgui
import xbmcplugin

import filmy

FILE = 'favourites.json'
FIELDS = ('kind', 'id', 'title', 'orig', 'year', 'poster', 'rating')


def _path():
    return os.path.join(filmy._ws()._profile, FILE)


def load():
    try:
        with io.open(_path(), 'r', encoding='utf8') as f:
            data = json.loads(f.read())
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save(rows):
    ws = filmy._ws()
    try:
        if not os.path.exists(ws._profile):
            os.makedirs(ws._profile)
        with io.open(_path(), 'w', encoding='utf8') as f:
            f.write(json.dumps(rows, ensure_ascii=False))
    except Exception:
        pass


def key(row):
    if row.get('kind') == 'tv':
        return 'tv:' + str(row.get('id', ''))
    return 'film:' + (row.get('title', '') + '|' + row.get('year', '')).lower()


def command(kind, m):
    """Polozka kontextove nabidky 'Pridat do oblibenych' pro film/serial z TMDB."""
    ws = filmy._ws()
    url = ws.get_url(action='fav_add', kind=kind, id=m.get('id') or '', title=m['title'], orig=m['orig'],
                     year=m['year'], poster=m['poster'], rating=m['rating'])
    return (u'Přidat do oblíbených', 'RunPlugin(' + url + ')')


def add(params):
    row = dict((k, params.get(k, '')) for k in FIELDS)
    row['u'] = round(time.time(), 3)
    rows = [r for r in load() if key(r) != key(row)]
    rows.insert(0, row)
    save(rows)
    import synchronizace
    synchronizace.sync()
    filmy._ws().popinfo(u'Přidáno do oblíbených: ' + row['title'])


def remove(params):
    save([r for r in load() if key(r) != params.get('key')])
    import synchronizace
    synchronizace.smazano('fav', params.get('key', ''))
    synchronizace.sync()
    xbmc.executebuiltin('Container.Refresh')


def menu(params):
    ws = filmy._ws()
    want_tv = params.get('kind') == 'tv'
    xbmcplugin.setPluginCategory(ws._handle, u'Obl\u00edben\u00e9 seri\u00e1ly' if want_tv else u'Obl\u00edben\u00e9 filmy')
    xbmcplugin.setContent(ws._handle, 'tvshows' if want_tv else 'movies')
    import synchronizace
    synchronizace.sync()
    rows = [r for r in load() if (r.get('kind') == 'tv') == want_tv]
    for r in rows:
        label = r.get('title', '?')
        if r.get('year'):
            label += ' (' + r['year'] + ')'
        try:
            if float(r.get('rating') or 0):
                label += u'  \u2605 %.1f' % float(r['rating'])
        except ValueError:
            pass
        li = xbmcgui.ListItem(label=label)
        if r.get('poster'):
            li.setArt({'poster': r['poster'], 'thumb': r['poster']})
        li.setInfo('video', {'title': label})
        li.addContextMenuItems([(u'Odebrat z obl\u00edben\u00fdch',
                                 'RunPlugin(' + ws.get_url(action='fav_remove', key=key(r)) + ')')])
        if want_tv:
            url = ws.get_url(action='tv_seasons', id=r.get('id', ''))
        else:
            url = ws.get_url(action='film_find', title=r.get('title', ''), orig=r.get('orig', ''), year=r.get('year', ''),
                             tmdb=r.get('id', ''))
        xbmcplugin.addDirectoryItem(ws._handle, url, li, True)
    if not rows:
        what = u'seri\u00e1lu' if want_tv else u'filmu'
        li = xbmcgui.ListItem(label=u'Zat\u00edm pr\u00e1zdn\u00e9 \u2013 u ' + what + u' podr\u017e ovlada\u010d a zvol P\u0159idat do obl\u00edben\u00fdch')
        xbmcplugin.addDirectoryItem(ws._handle, ws.get_url(action='fav_menu', kind=params.get('kind', 'film')), li, False)
    xbmcplugin.endOfDirectory(ws._handle)
